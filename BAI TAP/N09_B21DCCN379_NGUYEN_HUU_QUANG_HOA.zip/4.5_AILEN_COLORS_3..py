if __name__ == "__main__":
  ailen_color = input()
  if ailen_color == "green":
    print("You earned 5 points")
  elif ailen_color == "yellow":
    print("You earned 10 points")
  else: 
    print("You earned 15 points")