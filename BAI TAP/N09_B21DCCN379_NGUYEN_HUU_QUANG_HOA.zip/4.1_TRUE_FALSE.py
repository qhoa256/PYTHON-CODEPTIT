if __name__ == "__main__":
    name = "nguyenHuuQuangHoa"
    print("Is name == 'nguyenHuuQuangHoa'? I predict True.")
    print(name == "nguyenThiLan")
    print("\nIs name == 'nguyenThiLan'? I predict False.")
    print(name == "nguyenThiLan")

    age = 20
    print("Is age == '20'? I predict True.")
    print(age == "20")
    print("\nIs age == '21'? I predict False.")
    print(age == "21")

    birthDay = 25
    print("Is birdDay == '25'? I predict True.")
    print(birthDay == 25)
    print("\nIs birdDay == '3'? I predict False.")
    print(birthDay == 3)

    gender = "male"
    print("Is gender == 'male'? I predict True.")
    print(gender == "male")
    print("\nIs gender == 'female'? I predict False.")
    print(gender == "female")

    number = 256
    print("Is number == '256'? I predict True.")
    print(number == 256)
    print("\nIs number == '257'? I predict False.")
    print(number == 257)
