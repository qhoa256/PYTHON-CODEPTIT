if __name__ == "__main__":
  ailen_color = input()
  if ailen_color == "green":
    print("You earned 5 points")